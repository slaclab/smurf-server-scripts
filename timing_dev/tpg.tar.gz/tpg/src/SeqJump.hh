//
//  Builder for the SeqJump application registers
//
#ifndef SeqJump_hh
#define SeqJump_hh

#include <cpsw_api_builder.h>
#include <CpswTemplate.hh>

CpswTemplate(SeqJump)

#endif
