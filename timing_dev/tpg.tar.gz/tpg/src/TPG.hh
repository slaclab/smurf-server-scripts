//
//  Builder for the TPG application registers
//
#ifndef TPG_hh
#define TPG_hh

#include <cpsw_api_builder.h>
#include <CpswTemplate.hh>

CpswTemplate(TPG)

#endif
