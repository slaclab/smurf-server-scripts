//
//  Builder for the TPG application registers
//
#ifndef AmcGenericAdcDac_hh
#define AmcGenericAdcDac_hh

#include <cpsw_api_builder.h>
#include <CpswTemplate.hh>

CpswTemplate(AmcGenericAdcDac)

#endif
