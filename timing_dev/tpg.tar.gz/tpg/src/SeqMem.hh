//
//  Builder for the SeqMem application registers
//
#ifndef SeqMem_hh
#define SeqMem_hh

#include <cpsw_api_builder.h>
#include <CpswTemplate.hh>

CpswTemplate(SeqMem)

#endif
