//
//  Builder for the SeqState application registers
//
#ifndef SeqState_hh
#define SeqState_hh

#include <cpsw_api_builder.h>
#include <CpswTemplate.hh>

CpswTemplate(SeqState)

#endif
