#ifndef TPG_LCLS_HH
#define TPG_LCLS_HH

enum Destination { Injector, DiagLine, D10, HXU, SXU, NumberOf };
enum { NumberOfExptSeq = 1 };

#endif
