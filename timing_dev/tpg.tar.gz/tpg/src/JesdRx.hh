//
//  Builder for the JesdRx application registers
//
#ifndef JesdRx_hh
#define JesdRx_hh

#include <cpsw_api_builder.h>
#include <CpswTemplate.hh>

CpswTemplate(JesdRx)

#endif
